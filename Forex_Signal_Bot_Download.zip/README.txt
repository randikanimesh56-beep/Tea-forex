FOREX SIGNAL DESK — SETUP

Files
- index.html: upload this file to the root of your GitHub Pages repository.

Setup
1. Extract the ZIP.
2. Upload index.html to the root of your existing GitHub repository (replace the previous index.html if that is the page GitHub Pages serves).
3. Commit the change and wait for GitHub Pages to redeploy.
4. Open the published page and paste your Twelve Data API key into the existing API key field, then choose a timeframe and press Connect market data.

API key note
- The original API key input field and the original Twelve Data request/key interpolation have been preserved. The key is not hard-coded into this file.
- A key used in a public browser page may be visible to the browser/network tools. Use a restricted/low-quota key and do not reuse a sensitive key.

Signal rules and filters
- Base BUY: EMA 9 > EMA 21, RSI 14 > 50, MACD histogram > 0.
- Base SELL: EMA 9 < EMA 21, RSI 14 < 50, MACD histogram < 0.
- The added high-quality filter requires confluence score >= 80/100 before showing BUY/SELL; otherwise the display stays WAIT. The score is not a probability of winning.
- RSI uses Wilder smoothing. Candles are sorted oldest-to-newest before indicators are calculated.
- ATR and approximate session information are context only. Low ATR does not automatically block a signal. Session windows use UTC approximations and may shift with daylight-saving time.
- The historical check is a simplified educational backtest. It excludes spread, slippage, payout rules, execution delays and incomplete-candle effects. Past results do not guarantee future outcomes.
- Economic news, DXY and WebSocket live ticks are explicitly marked as not connected; the page does not invent those data.

Limits
- This file was syntax-checked locally, but live Twelve Data connection cannot be verified without your own working API key and provider quota. No profit or signal accuracy is guaranteed.
